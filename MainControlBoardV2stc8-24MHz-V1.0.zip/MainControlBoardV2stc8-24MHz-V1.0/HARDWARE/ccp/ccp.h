#ifndef _CCP_H
#define _CCP_H




#include <STC8.H>
#include "uart1.h"
#include "pbdata.h"

void ccp_Init();














#endif