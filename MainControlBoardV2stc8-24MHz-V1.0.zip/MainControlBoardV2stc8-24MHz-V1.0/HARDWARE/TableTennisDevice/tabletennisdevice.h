#ifndef _TABLETENNISDEVICE_H
#define _TABLETENNISDEVICE_H


#include "uart3.h"
#include <STC8.H>




void Artillery_Cmd(void);
void SteeringEngineAngle(u8 _angle);







#endif