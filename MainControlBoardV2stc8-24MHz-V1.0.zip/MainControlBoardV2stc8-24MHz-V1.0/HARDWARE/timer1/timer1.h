#ifndef _TIMER1_H
#define _TIMER1_H


#include <STC8.H>
#include "pbdata.h"
#include "djiReceiver_dr16.h"
#include "uart2.h"



void Timer0Init(void)		;

extern bit UsartFlag;












#endif