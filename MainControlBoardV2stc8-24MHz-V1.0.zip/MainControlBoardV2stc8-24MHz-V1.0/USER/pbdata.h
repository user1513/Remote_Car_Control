#ifndef _PBDATA_H
#define _PBDATA_H


typedef unsigned char u8;
typedef unsigned int u16;
typedef unsigned long u32;
#define tabletennisangleInit 85
enum
{
	Disable,
	Enable
};

enum
{
	Angle_0,
	Angle_45,
	Angle_90,
	Angle_135,
	Angle_180,
	Angle_225,
	Angle_270,
	Angle_315,
	AngleL_360,
	AngleR_360
};

#endif