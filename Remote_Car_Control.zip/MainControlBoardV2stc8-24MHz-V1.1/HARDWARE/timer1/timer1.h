#ifndef _TIMER1_H
#define _TIMER1_H


#include "appconf.h"

#if configUSE_TIMER1_MODE

void Timer0Init(void)		;

extern bit bDelayTimeFlag;


#endif









#endif