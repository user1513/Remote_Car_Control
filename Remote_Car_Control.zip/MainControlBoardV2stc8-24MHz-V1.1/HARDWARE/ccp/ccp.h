#ifndef _CCP_H
#define _CCP_H

#include "appconf.h"

#if configUSE_CCP_MODE
void ccp_Init();
#endif

#endif