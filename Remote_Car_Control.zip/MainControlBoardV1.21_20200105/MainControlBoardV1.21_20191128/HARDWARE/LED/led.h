#ifndef __LED_H
#define __LED_H

#include "sys.h"


#define LED_WORK	PBout(9)


void LED_Init(void);//IO��ʼ��
	

#endif
